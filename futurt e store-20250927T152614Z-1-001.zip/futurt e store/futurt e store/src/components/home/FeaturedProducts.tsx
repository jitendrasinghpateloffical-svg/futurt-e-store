import Link from 'next/link'
import { Star } from 'lucide-react'

const products = [
  {
    id: 1,
    name: 'Wireless Bluetooth Headphones',
    price: 99.99,
    originalPrice: 129.99,
    rating: 4.5,
    reviews: 128,
    vendor: 'TechGear Store',
    image: 'https://via.placeholder.com/300x300?text=Headphones',
    badge: 'Best Seller'
  },
  {
    id: 2,
    name: 'Organic Cotton T-Shirt',
    price: 24.99,
    rating: 4.8,
    reviews: 89,
    vendor: 'EcoFashion',
    image: 'https://via.placeholder.com/300x300?text=T-Shirt',
    badge: 'Eco-Friendly'
  },
  {
    id: 3,
    name: 'Smart Home Security Camera',
    price: 199.99,
    rating: 4.3,
    reviews: 256,
    vendor: 'HomeTech Solutions',
    image: 'https://via.placeholder.com/300x300?text=Security+Camera',
    badge: 'New'
  },
  {
    id: 4,
    name: 'Artisan Coffee Blend',
    price: 18.99,
    rating: 4.9,
    reviews: 342,
    vendor: 'Mountain Roasters',
    image: 'https://via.placeholder.com/300x300?text=Coffee',
    badge: 'Premium'
  }
]

export default function FeaturedProducts() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Featured Products
          </h2>
          <p className="text-lg text-gray-600">
            Discover the best products from our verified vendors
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="relative">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                {product.badge && (
                  <span className="absolute top-2 left-2 bg-primary-600 text-white px-2 py-1 text-xs font-semibold rounded">
                    {product.badge}
                  </span>
                )}
              </div>
              
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                  {product.name}
                </h3>
                
                <p className="text-sm text-gray-600 mb-2">by {product.vendor}</p>
                
                <div className="flex items-center mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600 ml-2">
                    ({product.reviews})
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-bold text-gray-900">
                      ${product.price}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">
                        ${product.originalPrice}
                      </span>
                    )}
                  </div>
                  <Link 
                    href={`/products/${product.id}`}
                    className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                  >
                    View
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link 
            href="/products"
            className="btn-primary inline-block"
          >
            View All Products
          </Link>
        </div>
      </div>
    </section>
  )
}