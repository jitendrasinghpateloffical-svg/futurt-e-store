import Link from 'next/link'

const categories = [
  { id: 1, name: 'Electronics', icon: '📱', count: 1250 },
  { id: 2, name: 'Fashion', icon: '👕', count: 2180 },
  { id: 3, name: 'Home & Garden', icon: '🏠', count: 890 },
  { id: 4, name: 'Sports', icon: '⚽', count: 567 },
  { id: 5, name: 'Books', icon: '📚', count: 1420 },
  { id: 6, name: 'Beauty', icon: '💄', count: 756 },
]

export default function Categories() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Shop by Category
          </h2>
          <p className="text-lg text-gray-600">
            Explore our wide range of product categories
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {categories.map((category) => (
            <Link 
              key={category.id}
              href={`/categories/${category.name.toLowerCase()}`}
              className="group"
            >
              <div className="bg-gray-50 rounded-lg p-6 text-center hover:bg-primary-50 transition-colors">
                <div className="text-4xl mb-3">{category.icon}</div>
                <h3 className="font-semibold text-gray-900 group-hover:text-primary-600">
                  {category.name}
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  {category.count} products
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}